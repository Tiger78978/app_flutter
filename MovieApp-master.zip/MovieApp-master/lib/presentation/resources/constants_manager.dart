class AppConstants{
  static const int splashDelay = 2;
}