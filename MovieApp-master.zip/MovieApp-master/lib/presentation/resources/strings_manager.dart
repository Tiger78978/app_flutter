class AppStrings{
  static const noRouteFound = 'No Route Found';


  static const skip ='Skip';
}