import 'dart:convert';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../domain/models.dart';
import 'api_constants.dart';



class ApiClient extends GetxController {
  Future<List<MovieModel>> getTrendingMovies() async {
    String url =
        '${ApiConstants.baseUrl}trending/movie/week?${ApiConstants.apiKEY}';

    try {
      http.Response response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);
      var result = data['results'];

      List<MovieModel> movies = [];
      for (var movie in result) {
        movies.add(MovieModel.fromJson(movie));
      }

      return movies;
    } catch (e) {
      rethrow;
    }
  }

  Future<List<MovieModel>> getNowPlayingMovies() async {
    String url =
        '${ApiConstants.baseUrl}movie/now_playing?${ApiConstants
        .apiKEY}&language=en-US&page=1';

    try {
      http.Response response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);
      var result = data['results'];

      List<MovieModel> movies = [];
      for (var movie in result) {
        movies.add(MovieModel.fromJson(movie));
      }

      return movies;
    } catch (e) {
      rethrow;
    }
  }

  Future<List<MovieModel>> getTopratedMovies() async {
    String url =
        '${ApiConstants.baseUrl}movie/top_rated?${ApiConstants
        .apiKEY}&language=en-US&page=1';

    try {
      http.Response response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);
      var result = data['results'];

      List<MovieModel> movies = [];
      for (var movie in result) {
        movies.add(MovieModel.fromJson(movie));
      }

      return movies;
    } catch (e) {
      rethrow;
    }
  }

  Future<List<MovieModel>> getPopularMovies() async {
    String url =
        '${ApiConstants.baseUrl}movie/popular?${ApiConstants.apiKEY}&language=en-US&page=1';

    try {
      http.Response response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);
      var result = data['results'];

      List<MovieModel> movies = [];
      for (var movie in result) {
        movies.add(MovieModel.fromJson(movie));
      }

      return movies;
    } catch (e) {
      rethrow;
    }
  }

  Future<List<MovieModel>> getUpcomingMovies() async {
    String url =
        '${ApiConstants.baseUrl}movie/upcoming?${ApiConstants.apiKEY}&language=en-US&page=1';

    try {
      http.Response response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);
      var result = data['results'];

      List<MovieModel> movies = [];
      for (var movie in result) {
        movies.add(MovieModel.fromJson(movie));
      }
      return movies;
    } catch (e) {
      rethrow;
    }
  }


  Future<MovieDetailModel> getMovieDetails(String movieId) async {
    String url =
        '${ApiConstants.baseUrl}movie/$movieId?${ApiConstants.apiKEY}&language=en-US';

    try {
      http.Response response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);

      MovieDetailModel details = MovieDetailModel.fromJson(data);

      return details;
    } catch (e) {
      rethrow;
    }
  }

 
  Future<List<CastModel>> getMovieCast(String movieId) async {
    String uri =
        '${ApiConstants.baseUrl}movie/$movieId/credits?${ApiConstants
        .apiKEY}&language=en-US';
    try {
      http.Response response = await http.get(Uri.parse(uri));
      final data = json.decode(response.body);
      var result = data['cast'];

      List<CastModel> movieCast = [];
      for (var cast in result) {
        movieCast.add(CastModel.fromJson(cast));
      }
      return movieCast;
    } catch (e) {
      rethrow;
    }
  }

  
  Future<List<Genres>> getMovieGenre(String movieId) async {
    String uri =
        '${ApiConstants.baseUrl}genre/movie/list?${ApiConstants
        .apiKEY}&language=en-US';
    try {
      http.Response response = await http.get(Uri.parse(uri));
      final data = json.decode(response.body);
      var result = data['genres'];

      List<Genres> movieGenre = [];
      for (var genres in result) {
        movieGenre.add(Genres.fromJson(genres));
      }
      return movieGenre;
    } catch (e) {
      rethrow;
    }
  }


  Future<List<MovieModel>> getSearchedMovies(String movieName) async {
    String url =
        '${ApiConstants.baseUrl}search/movie?${ApiConstants
        .apiKEY}&language=en-US&page=1&include_adult=false&query=$movieName';

    try {
      http.Response response = await http.get(Uri.parse(url));
      final data = json.decode(response.body);
      var results = data['results'];

      List<MovieModel> searchMovie = [];
      for (var movie in results) {
        searchMovie.add(MovieModel.fromJson(movie));
      }
      return searchMovie;
    } catch (e) {
      rethrow;
    }
  }
}
