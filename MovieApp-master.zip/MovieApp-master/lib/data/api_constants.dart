class ApiConstants {
  static const String baseUrl = "https://api.themoviedb.org/3/";
  static const String apiKEY = "api_key=67f666f35d0f24fba383a5fbf824d3bb";
  static const String baseImgUrl = "https://image.tmdb.org/t/p/original/";
}
